# Calculadora
 Calculadora Simples usando apenas HTML, CSS e JAVASCRIPT
